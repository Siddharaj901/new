
//////////////////// COLORS APP

const ColorsApp = {

    PRIMARY: "#10e689",
    SECONDARY: "#191818",
};

export default ColorsApp;
