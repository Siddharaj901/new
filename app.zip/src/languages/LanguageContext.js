import React from 'react';
 
const LanguageContext = React.createContext(null);
 
export default LanguageContext;